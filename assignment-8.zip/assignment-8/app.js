const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const multer = require('multer');
const path = require('path');
const fs = require('fs').promises;

const app = express();
const port = 3000;

app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.send('Library Management API is running!');
});

// Sample in-memory book data (replace with a database later)
let books = [];
let nextBookId = 1;

// Sample in-memory user data (replace with a database later)
const users = [];

// User Registration Route
app.post('/register', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required.' });
    }
    const userExists = users.find(user => user.username === username);
    if (userExists) {
        return res.status(409).json({ error: 'Username already exists.' });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = {
        id: users.length + 1,
        username: username,
        password: hashedPassword
    };
    users.push(newUser);
    res.status(201).json({ message: 'User registered successfully!' });
});

// User Login Route
app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = users.find(user => user.username === username);
    if (!user) {
        return res.status(401).json({ error: 'Invalid credentials.' });
    }
    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
        return res.status(401).json({ error: 'Invalid credentials.' });
    }
    res.json({ message: 'Login successful!', token: 'DUMMY_TOKEN' });
});

// Authentication Middleware
const authenticate = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token === 'DUMMY_TOKEN') {
        next();
    } else {
        res.status(401).json({ error: 'Unauthorized.' });
    }
};

// Book Management Routes (Protected)
app.post('/books', /*authenticate*/ (req, res) => {
    console.log('Authorization Header in /books:', req.headers['authorization']); // Add this line
    const { title, author, genre, year } = req.body;
    if (!title || !author || !genre || !year) {
        return res.status(400).json({ error: 'Missing required fields.' });
    }
    const newBook = { id: nextBookId++, title, author, genre, year };
    books.push(newBook);
    res.status(201).json(newBook);
});

app.put('/books/:id', authenticate, (req, res) => {
    const bookId = parseInt(req.params.id);
    const { title, author, genre, year } = req.body;
    const bookIndex = books.findIndex(book => book.id === bookId);

    if (bookIndex === -1) {
        return res.status(404).json({ error: 'Book not found.' });
    }

    books[bookIndex] = { ...books[bookIndex], title, author, genre, year };
    res.json(books[bookIndex]);
});

app.delete('/books/:id', authenticate, (req, res) => {
    const bookId = parseInt(req.params.id);
    books = books.filter(book => book.id !== bookId);
    res.status(204).send();
});

// Get Books Route (Public - no authentication)
app.get('/books', (req, res) => {
    const { page = 1, limit = 10, genre, author } = req.query;
    const pageNumber = parseInt(page);
    const limitNumber = parseInt(limit);
    const startIndex = (pageNumber - 1) * limitNumber;
    const endIndex = pageNumber * limitNumber;

    let filteredBooks = [...books];

    if (genre) {
        filteredBooks = filteredBooks.filter(book => book.genre.toLowerCase() === genre.toLowerCase());
    }

    if (author) {
        filteredBooks = filteredBooks.filter(book => book.author.toLowerCase() === author.toLowerCase());
    }

    const results = filteredBooks.slice(startIndex, endIndex);
    res.json({
        totalItems: filteredBooks.length,
        currentPage: pageNumber,
        totalPages: Math.ceil(filteredBooks.length / limitNumber),
        books: results,
    });
});

// Multer Configuration for File Uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, 'uploads');
        fs.mkdir(uploadDir, { recursive: true })
            .then(() => cb(null, uploadDir))
            .catch(err => cb(err));
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

// Serve Uploaded Files Statically
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// File Upload Routes (Protected)
app.post('/upload', authenticate, upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded.' });
    }
    res.status(200).json({ message: 'File uploaded successfully!', filename: req.file.filename, path: `/uploads/${req.file.filename}` });
});

app.get('/files', authenticate, async (req, res) => {
    const uploadDir = path.join(__dirname, 'uploads');
    try {
        const files = await fs.readdir(uploadDir);
        res.status(200).json({ files });
    } catch (error) {
        console.error('Error reading directory:', error);
        res.status(500).json({ error: 'Failed to list uploaded files.' });
    }
});

app.get('/files/:filename', authenticate, (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, 'uploads', filename);

    fs.access(filePath)
        .then(() => res.download(filePath, filename))
        .catch(() => res.status(404).json({ error: 'File not found.' }));
});

app.delete('/files/:filename', authenticate, async (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, 'uploads', filename);

    try {
        await fs.unlink(filePath);
        res.status(200).json({ message: 'File deleted successfully!' });
    } catch (error) {
        console.error('Error deleting file:', error);
        if (error.code === 'ENOENT') {
            return res.status(404).json({ error: 'File not found.' });
        }
        res.status(500).json({ error: 'Failed to delete file.' });
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
});