// Import the Express.js library
const express = require('express');

// Create an instance of the Express application
const app = express();

// Define the port the server will listen on
const port = 3000;

// Define the GET route for the home page ('/')
app.get('/', (req, res) => {
  res.send('Welcome to the Home Page');
});

// Define the GET route for the about page ('/about')
app.get('/about', (req, res) => {
  res.send('This is the About Page');
});

// Define the GET route for the contact page ('/contact')
app.get('/contact', (req, res) => {
  res.send('Contact us at: email@example.com');
});

// Error handling middleware for 404 Not Found
app.use((req, res, next) => {
  res.status(404).send('Page Not Found');
});

// Start the server and listen on the specified port
app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});