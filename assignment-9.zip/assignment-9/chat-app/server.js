const express = require('express');
const http = require('http');
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;

// Serve static files (like your HTML, CSS, and JS)
app.use(express.static('public'));

// Handle connection event
io.on('connection', (socket) => {
    console.log('A user connected:', socket.id);

    // Handle disconnection
    socket.on('disconnect', () => {
        console.log('User disconnected:', socket.id);
    });

    // Handle chat messages
    socket.on('chat message', (message) => {
        console.log('Message:', message);
        // Broadcast the message to all connected users
        io.emit('chat message', { message, senderId: socket.id }); // Include sender ID
    });
});

server.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
