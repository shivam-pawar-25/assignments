// index.js
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const app = express();
const port = 3000;

// Set up storage for uploaded files with versioning
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadPath = 'uploads/';
        // Create the directory if it doesn't exist
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const originalName = path.parse(file.originalname).name;
        const ext = path.parse(file.originalname).ext;
        let version = 1;
        let filename = `${originalName}_v${version}${ext}`;

        // Check for existing versions
        while (fs.existsSync(path.join('uploads/', filename))) {
            version++;
            filename = `${originalName}_v${version}${ext}`;
        }
        cb(null, filename);
    },
});

// File filter to allow only specific file types (optional)
const fileFilter = (req, file, cb) => {
    const allowedTypes = ['.jpg', '.jpeg', '.png', '.pdf', '.doc', '.docx']; // Example: Allow images and documents
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) {
        cb(null, true);
    } else {
        cb(new Error('Invalid file type. Only jpg, jpeg, png, pdf, doc, and docx files are allowed.'), false);
    }
};

// Set up multer with storage and file filter
const upload = multer({
    storage: storage,
    fileFilter: fileFilter,
    limits: {
        fileSize: 5 * 1024 * 1024, // 5MB limit (optional)
    },
});

// API to upload a single file
app.post('/upload', upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: 'No file provided.' });
    }
    res.status(200).json({
        message: 'File uploaded successfully.',
        filename: req.file.filename,
        path: req.file.path,
    });
});

// API to upload multiple files
app.post('/upload/multiple', upload.array('files', 5), (req, res) => { // Limit of 5 files
    if (!req.files || req.files.length === 0) {
        return res.status(400).json({ error: 'No files provided.' });
    }

    const fileDetails = req.files.map(file => ({
        filename: file.filename,
        path: file.path,
    }));

    res.status(200).json({
        message: 'Files uploaded successfully.',
        files: fileDetails,
    });
});

// API to get all uploaded files
app.get('/files', (req, res) => {
    const files = [];
    const uploadPath = 'uploads/';

     // Check if the directory exists
    if (!fs.existsSync(uploadPath)) {
        return res.status(200).json({ files: [] }); // Return empty array if directory does not exist
    }

    fs.readdirSync(uploadPath).forEach(file => {
        const filePath = path.join(uploadPath, file);
        const stats = fs.statSync(filePath);
        if (stats.isFile()) { // Ensure it's a file and not a directory
             files.push({
                name: file,
                size: stats.size, // Get file size
                createdAt: stats.birthtime,
                modifiedAt: stats.mtime
            });
        }
    });
    res.status(200).json({ files: files });
});

// API to download a file by filename
app.get('/download/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join('uploads/', filename);

    if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: 'File not found.' });
    }

    res.download(filePath, filename, (err) => {
        if (err) {
            // Handle errors during download (e.g., client disconnect)
            console.error('Download error:', err);
            res.status(500).json({ error: 'Failed to download file.' });
        }
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    if (err instanceof multer.MulterError) {
        // Handle Multer errors (e.g., file size limit exceeded)
        res.status(400).json({ error: err.message });
    } else if (err) {
        // Handle other errors
        res.status(500).json({ error: 'An error occurred: ' + err.message });
    } else {
        next(); // Pass control to the next middleware
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
